import React, { useContext, useState } from 'react'
import {assets} from '../assets/assets'
import {Link, NavLink} from 'react-router-dom'
import { ShopContext } from '../context/ShopContext';

const Navbar = () => {
  const [visible, setVisible]=useState(false);

  const {setShowSearch, CartCount} = useContext(ShopContext)

  return (
    <div className='flex items-center justify-around py-5 font-medium bg-blue-400 border border-black'>
      <Link to='/'><img src={assets.logo} className='w-36 bg-blue-400 ' alt="" /></Link>
      <ul className='hidden sm:flex gap-5 text-sm text-gray-900 bg-blue-400'>
        <NavLink to='/' className='bg-blue-400 flex flex-col items-start gap-1 hover:font-bold'>
          <p className='bg-blue-400'>HOME</p>
          <hr className='w-2/4 border-none h-[1.5px] bg-gray-700 mx-auto hidden '/>
        </NavLink>
        <NavLink to='/collection' className='bg-blue-400 flex flex-col items-start gap-1 hover:font-bold'>
          <p className='bg-blue-400'>COLLECTION</p>
          <hr className='w-2/4 border-none h-[1.5px] bg-gray-700 mx-auto hidden'/>
        </NavLink>
        <NavLink to='/about' className='flex flex-col items-start gap-1 hover:font-bold bg-blue-400'>
          <p className='bg-blue-400'>ABOUT</p>
          <hr className='w-2/4 border-none h-[1.5px] bg-gray-700 mx-auto hidden'/>
        </NavLink>
        <NavLink to='/contact' className='bg-blue-400 flex flex-col items-start gap-1 hover:font-bold'>
          <p className='bg-blue-400'>CONTACT</p>
          <hr className='w-2/4 border-none h-[1.5px] bg-gray-700 mx-auto hidden'/>
        </NavLink>
      </ul>
      <div className='flex items-center gap-6 bg-blue-400'>
        <img onClick={()=>setShowSearch(true)} src={assets.search_icon} className='w-5 cursor-pointer bg-blue-400' alt="" />
        <div className='group relative'>
         <Link to='/login'> <img src={assets.profile_icon} className='w-5 cursor-pointer bg-blue-400' alt="" /></Link>
          <div className='group-hover:block hidden absolute dropdown-menu right-0 pt-4 bg-blue-400'>
            <div className='flex flex-col gap-2 w-36 py-3 px-5 bg-white text-gray-500 rounded'>
              <p className='cursor-pointer hover:text-black bg-white hover:border-black hover:border'>My Profile</p>
              <p className='cursor-pointer hover:text-black bg-white  hover:border-black hover:border'>Orders</p>
              <p className='cursor-pointer hover:text-black bg-white  hover:border-black hover:border '>Logout</p>
            </div>
          </div>
        </div>
        <Link to='/cart' className='relative'>  
        <img src={assets.cart_icon} className='w-5 cursor-pointer min-w-5 bg-blue-400' alt="" />
        <p className='absolute right-[5px] bottom-[-5px] w-4 text-center leading-4 bg-black text-white aspect-square rounded-full text-[8px]'>{CartCount()}</p>
        </Link>
        <img onClick={()=>setVisible(true)} src={assets.menu_icon} className='w-5 cursor-pointer sm:hidden bg-blue-400' alt="" />
      </div >
      <div className={`absolute top-0 bottom-0 right-0 overflow-hidden bg-white transition-all ${visible ?'w-full':'hidden'}`}>
        <div className='flex flex-col text-gray-600'>
          <div onClick={()=>setVisible(false)} className='flex items-center gap-4 p-3 cursor-pointer'>
            <img className='h-4 rotate-180 ' src={assets.dropdown_icon} alt="" />
            <p>Back</p>
          </div>
          <NavLink onClick={()=>setVisible(false)} className='pl-6 py-2 border' to='/' >HOME</NavLink>
          <NavLink onClick={()=>setVisible(false)} className='pl-6 py-2 border' to='/collection' >COLLECTION</NavLink>
          <NavLink onClick={()=>setVisible(false)} className='pl-6 py-2 border' to='/about' >ABOUT</NavLink>
          <NavLink onClick={()=>setVisible(false)} className='pl-6 py-2 border' to='/contact' >CONTACT</NavLink>
        </div>
      </div>
    </div>
  )
}

export default Navbar
