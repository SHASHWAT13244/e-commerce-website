import React, { useState } from 'react'
import { backendUrl } from '../App'
import axios from 'axios'
import { toast } from 'react-toastify'

const Login = ({setToken}) => {

    const[email, setEmail] = useState('')
    const[password, setPassword] = useState('')


    const onSubmitHandler = async (e)=>{
        try {
            e.preventDefault();
          const response= await axios.post(backendUrl + '/api/user/admin', {email, password})
          if(response.data.success){
            setToken(response.data.token)
          }else{
            toast.error(response.data.message)
          }
        } catch (error) {   
            toast.error(response.message)
        }
    }
  return (
    <div className='min-h-screen flex items-center justify-center w-full'>
    <div className='bg-slate-200 shadow-xl rounded-lg px-8 py-6 max-w-md'>
      <h1 className='text-2xl font-bold mb-3'>Admin Panel</h1>
      <form onSubmit={onSubmitHandler}>
        <div className='mb-3 min-w-72'>
            <p className='text-sm font-medium text-gray-800 mb-3'>Email Address</p>
            <input onChange={(e)=>setEmail(e.target.value)} value= {email} className='rounded-md w-full px-3 outline-none border border-gray-500 py-3' type="email" placeholder='your@email.com' required />
        </div>
        <div className='mb-3 min-w-72'>
            <p className='text-sm font-medium text-gray-800 mb-3'>Password</p>
            <input onChange={(e)=>setPassword(e.target.value)} value= {password} className='rounded-md w-full px-3 outline-none border border-gray-500 py-3' type="password" placeholder='Enter your password' required />
        </div>
        <button className='mt-2 w-full py-2 px-4 rounded-md text-white  bg-black' type='submit'>Login</button>
      </form>
    </div>
    </div>
  )
}
export default Login
