import React from 'react'
import { assets } from '../assets/assets'

const Hero = () => {
  return (
    <div className='flex flex-col sm:flex-row border  border-gray-400 '>
      <div className='w-full sm:w-1/2 flex items-center justify-center py-10 sm:py-0 bg-white'>
      <div className='text-[#414141]'>
        <div className='flex items-center gap-3 bg-white'>
            <p className='w-8 md:w-11 h-[2px] bg-[#414141]'></p>
            <p className='font-medium text-sm md:text-base bg-white'>BESTSELLERS🔥🔥🔥</p>
        </div>
        <h1 className='prata-regular text-3xl sm:py-3 lg:text-5xl leading-relaxed bg-white'>Latest Arrivals</h1>
        <div className='flex items-center gap-2 bg-white'>
            <p className='font-semibold text-sm md:text-base bg-white'>SHOP NOW</p>
            <p className='w-8 md:w-11 h-[1px] bg-[#414141]'></p>
        </div>
      </div>
      </div>
      <img className='w-full sm:w-1/2 ' src={assets.hero_img} alt="" />
    </div>
  )
}

export default Hero
 